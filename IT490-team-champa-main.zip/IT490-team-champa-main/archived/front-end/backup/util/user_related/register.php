<?php 
require_once('../../config/log.php');
require_once('../../config/get_host_info.inc');
require_once('../../config/rabbitMQLib.inc');

//initialize username and password

$username = "";
$password = "";

session_start();

if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		//$username = $_POST['username'];
		//$password = $_POST['password'];

        $client = new rabbitMQClient("../../config/testRabbitMQ.ini","RabbitMQServer");
        $requestToServer = array();
        $requestToServer['type'] = "create";
        $requestToServer['username'] = $_POST["username"];
        $requestToServer['password'] = $_POST["password"];
        $response = $client->send_request($requestToServer);
		if($response['isCreated'] == 'true'){
			include_once('check_session_timeout.php');
        	header("Location: /index.html");
        	exit();
		}
		else{
			$error_message = "Invalid credentials. Please try again.";
        	header("Location: /index.html");
        	exit();
		}
	}
?>