function checkSessionTimeout() {
    // Make an AJAX request to the PHP script
    fetch('check_session_timeout.php')
        .then(response => response.json())
        .then(data => {
            if (data.timeoutExpired) {
                // Session has timed out, take appropriate action (e.g., redirect to login)
                alert('Your session has timed out. Please log in again.');
                window.location.href = 'index.html';
            }
        })
        .catch(error => {
            console.error('Error checking session timeout:', error);
        });
}
 
function checkLoggedIn() {
    // Make an AJAX request to the PHP script
    fetch('check_login.php')
        .then(response => response.json())
        .then(data => {
            if(data.isLoggedIn){
                // Call the function initially and then every minute (60,000 milliseconds)
                checkSessionTimeout();
                setInterval(checkSessionTimeout, 60000);
            }
            else{
                alert('You are not authorized to this part of the website.');
                window.location.href = 'index.html';
            }
        })
        .catch(error => {
            console.error('Error checking session timeout:', error);
        });
}
this.checkLoggedIn()

