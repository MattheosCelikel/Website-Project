function logout() {
    // Make an AJAX request to the PHP script
	console.log("Logout function is called");
    fetch('logout.php')
        .then(response => response.json())
        .then(data => {
           alert('You have logged out. Returning to home page.');
           window.location.href = 'index.html';
            
        })
        .catch(error => {
            console.error('Error checking session timeout:', error);
        }); 
}