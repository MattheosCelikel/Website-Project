<?php
require_once('../../config/log.php');
require_once('../../config/get_host_info.inc');
require_once('../../config/rabbitMQLib.inc');

// Initialize variables for username and password
$username = "";
$password = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $client = new rabbitMQClient("../../config/testRabbitMQ.ini","RabbitMQServer");
    $requestToServer = array();
    $requestToServer['type'] = "login";
    $requestToServer['username'] = $_POST["username"];
    $requestToServer['password'] = $_POST["password"];
    $response = $client->send_request($requestToServer);


    // Check if credentials are valid
    if ($response['isLoggedIn'] == 'true') {
        include_once('check_session_timeout.php');
        header("Location: /index.html");
        exit();
    } else {
        // Authentication failed
        $error_message = "Invalid credentials. Please try again.";
        header("Location: /index.html");
        exit();
    }
}
?>
