<?php
session_start();

$response = array();

// Check if the user is logged in (you can customize this check)
if (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn']=='true') {
    $response['isLoggedIn'] = $_SESSION['isLoggedIn'];
} else if (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn']=='false'){
    $response['isLoggedIn'] = false;
}
else{
    $response['isLoggedIn'] = null;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
