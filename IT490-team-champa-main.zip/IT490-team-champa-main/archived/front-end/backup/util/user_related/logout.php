<?php
//If something comes in here then it's assumed that the user logged in at some point and it's checking if it's time to timeout the user
session_start();

$response = array();

unset($_SESSION['last_activity']);
unset($_SESSION['isLoggedIn']);

$response['isLoggedOut'] = true;

header('Content-Type: application/json');
echo json_encode($response);
?>

