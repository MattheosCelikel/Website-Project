#!/usr/bin/php
<?php

require_once('../config/log.php');

require_once('../config/get_host_info.inc');
require_once('../config/rabbitMQLib.inc');

$client = new rabbitMQClient("../config/testRabbitMQ.ini","RabbitMQServer");
$requestToServer = array();
$requestToServer['type'] = "login";
$requestToServer['username'] = "testUser";
$requestToServer['password'] = "12345";
$response = $client->send_request($requestToServer);

var_dump($response);
?>
