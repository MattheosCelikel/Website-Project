#!/usr/bin/php
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './vendor/phpmailer/phpmailer/src/Exception.php';
require './vendor/phpmailer/phpmailer/src/PHPMailer.php';
require './vendor/phpmailer/phpmailer/src/SMTP.php';

function generate2FACode() {
    return rand(100000, 999999);
}

$mail = new PHPMailer(true);

try {
    // SMTP configuration
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'foodlovers.teamchampa@gmail.com';
    $mail->Password   = 'yyeu ctqr ymeq nkwy';
    $mail->SMTPSecure = 'ssl';
    $mail->Port       = 465;

    // Recipients
    $mail->setFrom('foodlovers.teamchampa@gmail.com', 'Mailer');
    $mail->addAddress('aratmurat1999@gmail.com', 'User Name'); // Replace with user's email

    // Content
    $code = generate2FACode();
    $mail->isHTML(true);
    $mail->Subject = 'Your 2FA Code';
    $mail->Body    = 'Your 2FA code is: ' . $code;

    $mail->send();
    echo '2FA code sent successfully';

    // Save the code to a local file (for demonstration only)
    file_put_contents('2fa_code.txt', $code);

} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>

