#!/usr/bin/php
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userCode = $_POST['code'];
    $savedCode = file_get_contents('2fa_code.txt');

    if ($userCode == $savedCode) {
        echo "2FA Verification Successful!";
    } else {
        echo "Incorrect code. Please try again.";
    }
}
?>

<form method="post" action="verify_2fa.php">
    Enter the 2FA code: <input type="text" name="code">
    <input type="submit">
</form>

