<?php 
require_once('../../config/get_host_info.inc');
require_once('../../config/rabbitMQLib.inc');

session_start();

if($_SERVER['REQUEST_METHOD'] == "POST")
	{
        $client = new rabbitMQClient("../../config/testRabbitMQ.ini","RabbitMQServer");
        $requestToServer = array();
        $requestToServer['type'] = "submit_meals_and_excercises";
        $requestToServer['USER_ID'] = $_SESSION["USER_ID"];
        $requestToServer['MEAL'] = $_POST["MEAL"];
		$requestToServer['EXERCISE'] = $_POST["EXERCISE"];
        $response = $client->send_request($requestToServer);
		if($response['isCreated'] == 'true'){
			include_once('check_session_timeout.php');
        	header("Location: /index.html");
        	exit();
		}
		else{
			$error_message = "Invalid credentials. Please try again.";
        	header("Location: /index.html");
        	exit();
		}
	}
?>