
// JavaScript to handle the login form pop-up
document.addEventListener('DOMContentLoaded', function() {
    const loginButton = document.getElementById('loginButton');
    const loginModal = document.getElementById('loginModal');
    const closeBtn = document.querySelector('.close');
 
    loginButton.addEventListener('click', function() {
        loginModal.style.display = 'block';
    });

    closeBtn.addEventListener('click', function() {
        loginModal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === loginModal) {
            loginModal.style.display = 'none';
        }
    });
});
fetch('/util/user_related/check_login.php')
    .then(response => response.json())
    .then(data => {
        if (data.isLoggedIn) {
            document.getElementById('loginButton').style.display = 'none';
            document.getElementById('registerButton').style.display = 'none';
            document.getElementById('logoutButton').style.display = 'inline-block';
        } else {
            document.getElementById('loginButton').style.display = 'inline-block';
            document.getElementById('registerButton').style.display = 'inline-block';
            document.getElementById('logoutButton').style.display = 'none';
        }
    });

document.addEventListener('DOMContentLoaded', function() {
    const registerButton = document.getElementById('registerButton');
    const registerModal = document.getElementById('registerModal');
    const closeBtn = document.querySelector('.registerClose');

    registerButton.addEventListener('click', function() {
        registerModal.style.display = 'block';
    });

    closeBtn.addEventListener('click', function() {
        registerModal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === registerModal) {
            registerModal.style.display = 'none';
        }
    });

});