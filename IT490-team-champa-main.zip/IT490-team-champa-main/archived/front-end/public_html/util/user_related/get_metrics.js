fetch('/util/user_related/get_metrics.php')
    .then(response => response.json()) // Assuming the PHP script returns JSON
    .then(data => {
        console.log(data);
        // // Populate form fields with the received data
        document.getElementById('GENDER').value = data.GENDER;
        document.getElementById('AGE').value = data.AGE;
        document.getElementById('HEIGHT').value = data.HEIGHT;
        document.getElementById('MEASUREMENT_HEIGHT_TYPE').value = data.MEASUREMENT_HEIGHT_TYPE;
        document.getElementById('WEIGHT').value = data.WEIGHT;
        document.getElementById('MEASUREMENT_WEIGHT_TYPE').value = data.MEASUREMENT_WEIGHT_TYPE;
        document.getElementById('BODYFAT').value = data.BODYFAT;
        // Assuming ACTIVITY is an array of options, populate the select element
        const activitySelect = document.getElementById('ACTIVITY');
        for (let i = 0; i < activitySelect.options.length; i++) {
            if (activitySelect.options[i].value == data.ACTIVITY_ID) {
                activitySelect.options[i].selected = true;
                break;
            }
        }
        document.getElementById('GOAL').value = data.GOAL;
    })
    .catch(error => console.error('Error fetching data:', error));
