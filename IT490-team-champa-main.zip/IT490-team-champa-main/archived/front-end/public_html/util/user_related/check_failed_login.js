function invalidLogin() {
    // Make an AJAX request to the PHP script
	console.log("Wrong username or password is input");
    fetch('/util/user_related/check_login.php')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if(data.isLoggedIn==false){
                alert('Invalid credentials. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error check_login.php', error);
        }); 
}

this.invalidLogin()