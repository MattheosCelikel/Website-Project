<?php
session_start();

$response = array();

// Check if the user is logged in
if (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn'] == 'true') {
    $response['isLoggedIn'] = $_SESSION['isLoggedIn'];
} 
else if (isset($_SESSION['isLoggedIn'])){
    $response['isLoggedIn'] = false;
    //unset($_SESSION['isLoggedIn']);
}
else{
    $response['isLoggedIn'] = null;
}
$response['isLoggedIn'] = $_SESSION['isLoggedIn'];
header('Content-Type: application/json');
echo json_encode($response);
?>
