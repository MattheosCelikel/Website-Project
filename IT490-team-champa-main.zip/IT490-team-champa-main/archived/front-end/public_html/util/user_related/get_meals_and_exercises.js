// Get the select element
const mealContainer = document.getElementById('MEALS_EATEN');
const exerciseContainer = document.getElementById('EXERCISES');

// Fetch data from test.php
fetch('/util/user_related/get_meals_and_exercises.php')
    .then(response => response.json()) // Assuming the PHP script returns JSON
    .then(data => {
        // Loop through the data and create options
        data['MEALS_EATEN'].forEach(item => {
            console.log(item);
            const container = document.createElement('div');

            const mealNamelabel = document.createElement('label');

            mealNamelabel.textContent = 'Meal Name: ' + item.MEAL;

            container.appendChild(mealNamelabel);
            mealContainer.appendChild(container);

        });

        data['EXERCISES'].forEach(item => {
            console.log(item);
            const container = document.createElement('div');

            const mealNamelabel = document.createElement('label');

            mealNamelabel.textContent = 'Exercise Name: ' + item.EXERCISE;

            container.appendChild(mealNamelabel);
            exerciseContainer.appendChild(container);

        });
    })
    .catch(error => console.error('Error fetching data:', error));