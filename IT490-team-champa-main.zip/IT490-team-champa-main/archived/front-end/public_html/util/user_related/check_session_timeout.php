<?php
//If something comes in here then it's assumed that the user logged in at some point and it's checking if it's time to timeout the user
session_start();

$response = array();

// Set the session timeout duration in seconds (e.g., 15 minutes)
$minutes = 5;
$timeoutDuration = 60 * $minutes; // 5 minutes

if (isset($_SESSION['last_activity'])) {
    $current_time = time();
    $last_activity_time = $_SESSION['last_activity'];
    $time_difference = $current_time - $last_activity_time;

    if ($time_difference >= $timeoutDuration) {
        // Session has timed out; unset the last_activity timestamp
        unset($_SESSION['last_activity']);
        unset($_SESSION['isLoggedIn']);
        unset($_SESSION['USER_ID']);
        $response['timeoutExpired'] = true;
    } else {
        $response['timeoutExpired'] = false;
    }
} else {
    // Initialize the last_activity timestamp and isLoggedIn if it's not set
    $_SESSION['last_activity'] = time();
    $_SESSION['isLoggedIn'] = true;
    $response['isLoggedIn'] = true;
    $response['timeoutExpired'] = false;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
