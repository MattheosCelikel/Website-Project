<?php 
require_once('../../config/get_host_info.inc');
require_once('../../config/rabbitMQLib.inc');

session_start();

if($_SERVER['REQUEST_METHOD'] == "POST")
	{
        $client = new rabbitMQClient("../../config/testRabbitMQ.ini","RabbitMQServer");
        $requestToServer = array();
        $requestToServer['type'] = "input_metrics";
        $requestToServer['USER_ID'] = $_SESSION["USER_ID"];
        $requestToServer['MEASUREMENT_HEIGHT_TYPE'] = $_POST["MEASUREMENT_HEIGHT_TYPE"];
        $requestToServer['MEASUREMENT_WEIGHT_TYPE'] = $_POST["MEASUREMENT_WEIGHT_TYPE"];
        $requestToServer['GENDER'] = $_POST["GENDER"];
        $requestToServer['AGE'] = $_POST["AGE"];
        $requestToServer['HEIGHT'] = $_POST["HEIGHT"];
        $requestToServer['WEIGHT'] = $_POST["WEIGHT"];
        $requestToServer['BODYFAT'] = $_POST["BODYFAT"];
        $requestToServer['ACTIVITY'] = $_POST["ACTIVITY"];
        $requestToServer['GOAL'] = $_POST["GOAL"];
        $response = $client->send_request($requestToServer);
		if($response['isCreated'] == 'true'){
			include_once('check_session_timeout.php');
        	header("Location: /index.html");
        	exit();
		}
		else{
			$error_message = "Invalid credentials. Please try again.";
        	header("Location: /index.html");
        	exit();
		}
	}
?>