// Get the select element
const selectElement = document.getElementById('BLOG_POSTS');

// Fetch data from test.php
fetch('/util/user_related/get_blog_posts.php')
    .then(response => response.json()) // Assuming the PHP script returns JSON
    .then(data => {
        // Loop through the data and create options
        data.forEach(item => {
            console.log(item);
            const container = document.createElement('div');
            const label = document.createElement('label');
            const textArea = document.createElement('textarea');

            const breakTag1 = document.createElement('br');
            const breakTag2 = document.createElement('br');
            const breakTag3 = document.createElement('br');
            
            label.textContent = 'Blog post by: ' + item.USERNAME;
            textArea.textContent = item.USER_TEXT;
            textArea.disabled = true;
            container.appendChild(label)
            container.appendChild(breakTag1);;
            container.appendChild(textArea);
            container.appendChild(breakTag2);
            container.appendChild(breakTag3);
            selectElement.appendChild(container);
        });
    })
    .catch(error => console.error('Error fetching data:', error));