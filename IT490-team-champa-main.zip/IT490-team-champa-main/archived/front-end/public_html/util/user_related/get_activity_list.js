// Get the select element
const selectElement = document.getElementById('ACTIVITY');

// Fetch data from test.php
fetch('/util/user_related/get_activity_list.php')
    .then(response => response.json()) // Assuming the PHP script returns JSON
    .then(data => {
        // Loop through the data and create options
        data.forEach(item => {
            const option = document.createElement('option');
            option.value = item.ACTIVITY_ID;
            option.text = item.ACTIVITY_ID;
            selectElement.appendChild(option);
        });
    })
    .catch(error => console.error('Error fetching data:', error));