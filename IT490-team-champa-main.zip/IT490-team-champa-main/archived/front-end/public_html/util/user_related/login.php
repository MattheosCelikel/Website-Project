<?php

require_once('../../config/get_host_info.inc');
require_once('../../config/rabbitMQLib.inc');

session_start();


// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $client = new rabbitMQClient("../../config/testRabbitMQ.ini","RabbitMQServer");
    $requestToServer = array();
    $requestToServer['type'] = "login";
    $requestToServer['USERNAME'] = $_POST["USERNAME"];
    $requestToServer['PASSWORD'] = $_POST["PASSWORD"];
    $response = $client->send_request($requestToServer);


    // Check if credentials are valid
    if ($response["isLoggedIn"] == 'true') {
        $_SESSION['USER_ID'] = $response['USER_ID'];
        include_once('check_session_timeout.php');
        header("Location: /index.html");
        exit();
    } else {
        // Authentication failed
        $error_message = "Invalid credentials. Please try again.";
        $_SESSION['isLoggedIn'] = false;
        header("Location: /index.html");
        exit();
    }
}
?>

