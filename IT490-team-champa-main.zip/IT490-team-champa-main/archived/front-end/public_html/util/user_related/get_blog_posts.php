<?php
require_once('../../config/get_host_info.inc');
require_once('../../config/rabbitMQLib.inc');

session_start();

$client = new rabbitMQClient("../../config/testRabbitMQ.ini","RabbitMQServer");
$requestToServer = array();
$requestToServer['type'] = "get_blog_posts";
$response = $client->send_request($requestToServer);
echo json_encode($response);
?>