// Get the select element
const selectElement = document.getElementById('CONTAINER');

// Fetch data from test.php
fetch('/util/user_related/get_meal_recommendation.php')
    .then(response => response.json()) // Assuming the PHP script returns JSON
    .then(data => {
         // Create a table element
         const table = document.createElement('table');

         // Create a table header row
         const headerRow = table.insertRow();
         for (const key in data[0]) {
             if (data[0].hasOwnProperty(key)) {
                 const headerCell = headerRow.insertCell();
                 headerCell.textContent = key;
             }
         }
 
         // Loop through the data and create table rows
         data.forEach(item => {
             const row = table.insertRow();
             for (const key in item) {
                 if (item.hasOwnProperty(key)) {
                     const cell = row.insertCell();
                     cell.textContent = item[key];
                 }
             }
         });
 
         // Append the table to the container
         selectElement.appendChild(table);
    })
    .catch(error => console.error('Error fetching data:', error));