<?php 
require_once('../../config/log.php');
require_once('../../config/get_host_info.inc');
require_once('../../config/rabbitMQLib.inc');

//initialize username and password

$username = "";
$password = "";

session_start();

if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		//$username = $_POST['username'];
		//$password = $_POST['password'];

        $client = new rabbitMQClient("../../config/testRabbitMQ.ini","RabbitMQServer");
        $requestToServer = array();
        $requestToServer['type'] = "create";
        $requestToServer['USERNAME'] = $_POST["USERNAME"];
        $requestToServer['PASSWORD'] = password_hash($_POST["PASSWORD"], PASSWORD_DEFAULT);
		$requestToServer['FIRST_NAME'] = $_POST["FIRSTNAME"];
        $requestToServer['LAST_NAME'] = $_POST["LAST_NAME"];
		$requestToServer['EMAIL'] = $_POST["EMAIL"];
        $response = $client->send_request($requestToServer);
		if($response['isCreated'] == 'true'){
			$_SESSION['USER_ID'] = $response['USER_ID'];
			include_once('check_session_timeout.php');
        	header("Location: /index.html");
        	exit();
		}
		else{
			$error_message = "Invalid credentials. Please try again.";
        	header("Location: /index.html");
        	exit();
		}
	}
?>