// Get the select element
const selectElement = document.getElementById('RATINGS');

// Fetch data from test.php
fetch('/util/user_related/get_ratings.php')
    .then(response => response.json()) // Assuming the PHP script returns JSON
    .then(data => {
        // Loop through the data and create options
        data.forEach(item => {
            console.log(item);
            const container = document.createElement('div');

            const label = document.createElement('label');
            const ratingLabel = document.createElement('label');
            const mealNamelabel = document.createElement('label');
            
            const textArea = document.createElement('label');

            const breakTag1 = document.createElement('br');
            const breakTag2 = document.createElement('br');
            const breakTag3 = document.createElement('br');
            const breakTag4 = document.createElement('br');
            const breakTag5 = document.createElement('br');
            label.textContent = 'Review by: ' + item.USERNAME;
            ratingLabel.textContent = 'Rating: ' + item.RATING + " Stars";
            mealNamelabel.textContent = 'Meal Name: ' + item.MEAL_NAME;

            textArea.textContent ='Comment: ' + item.COMMENT;
            textArea.disabled = true;
            container.appendChild(label);
            container.appendChild(breakTag1);
            container.appendChild(ratingLabel);
            container.appendChild(breakTag2);
            container.appendChild(mealNamelabel);
            container.appendChild(breakTag3);
            container.appendChild(textArea);
            container.appendChild(breakTag4);
            container.appendChild(breakTag5);
            selectElement.appendChild(container);
        });
    })
    .catch(error => console.error('Error fetching data:', error));