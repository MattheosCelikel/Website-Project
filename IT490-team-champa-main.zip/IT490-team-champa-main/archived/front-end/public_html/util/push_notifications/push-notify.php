<?php
    // if there is anything to notify, then return the response with data for
    // push notification else just exit the code
    $webNotificationPayload['title'] = 'Click to add your newest meal!';
    $webNotificationPayload['body'] = 'Don\'t forget to eat and let us know.';
    $webNotificationPayload['icon'] = '/util/push_notifications/champa_logo.png';
    $webNotificationPayload['url'] = 'https://www.testdomain.com/meal_and_exercises.html';
    echo json_encode($webNotificationPayload);
    exit();
?>