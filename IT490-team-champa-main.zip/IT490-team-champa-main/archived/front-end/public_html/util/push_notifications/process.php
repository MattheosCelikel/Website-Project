<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     // Access form data
//     $phoneNumber = $_POST['phoneNumber'];

//     // Do something with the form data
//     // For example, you might validate and insert into a database

//     // Send a response (for example, a JSON response)
//     $response = array(
//         'status' => 'success',
//         'message' => 'Form data received successfully',
//         'phoneNumber' => $phoneNumber
//     );

//     // Send the response as JSON
//     header('Content-Type: application/json');
//     echo json_encode($response);
// } else {
//     // Invalid request method
//     $response = array(
//         'status' => 'error',
//         'message' => 'Invalid request method'
//     );

//     // Send an error response as JSON
//     header('Content-Type: application/json');
//     echo json_encode($response);
// }



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["phoneNumber"])) {
        // Twilio Account SID, Auth Token, and Twilio phone number
        $accountSid = 'AC29f3eab293139865ace4fff817494b28';
        $authToken = '07f37241be1f680ec781ae55b6fc517a';
        $twilioPhoneNumber = '18339876009';

        // Recipient's phone number and message content
        $toPhoneNumber = '1' . $_POST["phoneNumber"];
        $messageBody = 'Make sure to eat and rate your food!!';

        // Twilio API URL
        $twilioApiUrl = 'https://api.twilio.com/2010-04-01/Accounts/' . $accountSid . '/Messages.json';

        // Prepare cURL request
               
        $ch = curl_init($twilioApiUrl);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "To=$toPhoneNumber&From=$twilioPhoneNumber&Body=$messageBody");
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, "$accountSid:$authToken");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded'
        ]);

        // Execute cURL request
        $response = curl_exec($ch);

        // Check for errors
        if (curl_errno($ch)) {
            echo json_encode(['status' => 'curlError', 'message' => 'Curl Error']);
        } else {
            // Decode and print the Twilio response
            $twilioResponse = json_decode($response, true);
            echo json_encode(['data' => 'Success', 'twilioResponse' => $twilioResponse]);
        }

        // Close cURL session
        curl_close($ch);


    }
    else{
        echo json_encode(array('status' => 'error',
            'message' => 'Invalid request method'));
    }
    
}
?>
