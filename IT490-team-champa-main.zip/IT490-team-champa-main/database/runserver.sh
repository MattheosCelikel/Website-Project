#!/bin/bash
php /home/bas64/Desktop/IT490-team-champa/database/testRabbitMQServer.php
sudo systemctl restart dbserver