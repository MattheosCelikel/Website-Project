# Structuring of front-end content

- Image folder
    - Stores all of the images
- Scripts folder
    - Stores all of the javascript functionality
- PHP folder
	- Stores all of the php functionality
- Misc folder
	- Content that cannot be categorized in any other folder
- Html Files
	- They are in the root directory (public_html)
