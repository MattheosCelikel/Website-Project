# IT490 Project
WIP README

README intended for group members:

Frontend folder is intended for device hosting the apache server.
Rabbitmq_example folder is intended for the device hosting the rabbitmq broker server
Backend is meant to house the database listener
