<?php
// config.php

function getToken(){
    return "db2592b4-191b-4643-a85b-d0dc8d3c73de";
}
?>