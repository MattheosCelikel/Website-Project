#!/bin/bash
php /home/vboxuser/Downloads/IT490-team-champa/calorie_king_api/testRabbitMQServer.php
