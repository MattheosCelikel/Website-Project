#!/bin/bash
php ./testRabbit.php;